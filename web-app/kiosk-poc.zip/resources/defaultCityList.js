const cityList = {
  cities: ["Atlanta", "Boston", "Austin", "San Francisco"],
};
