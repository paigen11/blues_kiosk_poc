var cityList = {
  cities: ["San Jose", "San Clemente", "San Bernadino", "San Sebastien"],
};
